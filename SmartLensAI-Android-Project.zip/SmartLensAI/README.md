# Smart Lens AI (Android MVP)

Native Android camera starter project for Android 11+ devices, including Redmi Note 8.

## Features
- CameraX live preview with front/back camera switching.
- Captures a JPEG and saves the original plus a restrained enhanced copy to Pictures/SmartLensAI.
- Enhancement uses global pixel processing only (gentle contrast/brightness and mild sharpening). No face detection, reshaping, synthesis, or beauty retouching.
- Processing is on-device; images are not uploaded.

## Build from a phone using GitHub Actions
1. Create a GitHub account/sign in at https://github.com.
2. Create a new **Public** repository named `SmartLensAI` (public is needed for the simplest free Actions workflow).
3. Upload the contents of this folder to the repository root (the `app` folder, root Gradle files, and `.github` folder must be at the top level; do not upload an extra enclosing `SmartLensAI` folder).
4. Open the repository's **Actions** tab and enable workflows if asked.
5. Open **Build Smart Lens AI APK** and tap **Run workflow**. If it does not appear, push/commit the uploaded files to the `main` branch.
6. When the run completes successfully, open the run, scroll to **Artifacts**, and download `SmartLensAI-debug-apk`.
7. Extract the downloaded artifact ZIP; install `app-debug.apk`. Android may ask you to allow installs from that browser/file manager.

## Local build
Requires JDK 17, Android SDK Platform 35, and Gradle 8.9. Run `gradle assembleDebug` from the project root.

## Limitations
- This MVP enhances after capture; the live camera preview is not filtered in real time.
- Global color/contrast adjustments can affect perceived skin tones slightly; facial geometry is not altered and no beauty filter is applied.
- Test camera behavior and performance on the actual device before relying on it.
