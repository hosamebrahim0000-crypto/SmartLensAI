package com.smartlens.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var captureButton: Button
    private lateinit var switchButton: Button
    private lateinit var statusText: TextView
    private var imageCapture: ImageCapture? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private lateinit var cameraExecutor: ExecutorService

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else showStatus("يلزم السماح باستخدام الكاميرا لتشغيل التطبيق")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraExecutor = Executors.newSingleThreadExecutor()
        buildInterface()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(16, 18, 22))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val header = TextView(this).apply {
            text = "SMART LENS AI\nتصوير أوضح.. من غير تغيير ملامحك"
            setTextColor(Color.WHITE); textSize = 18f; gravity = Gravity.CENTER
            setPadding(12, 20, 12, 18)
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        statusText = TextView(this).apply {
            text = "المعالجة تحافظ على شكل الوجه؛ تحسينات ضوئية عامة فقط"
            setTextColor(Color.LTGRAY); textSize = 13f; gravity = Gravity.CENTER
            setPadding(12, 12, 12, 8)
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(12, 10, 12, 22)
        }
        switchButton = Button(this).apply { text = "تبديل الكاميرا"; setOnClickListener { switchCamera() } }
        captureButton = Button(this).apply {
            text = "التقاط وتحسين"; textSize = 16f
            setOnClickListener { takePhoto() }
        }
        controls.addView(switchButton, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(captureButton, LinearLayout.LayoutParams(0, -2, 1.3f))
        root.addView(header)
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(statusText)
        root.addView(controls)
        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(96)
                .build()
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, imageCapture)
                showStatus("جاهز للتصوير • احتفاظ بالصورة الأصلية والنسخة المحسّنة")
            } catch (e: Exception) {
                showStatus("تعذر تشغيل الكاميرا: ${e.localizedMessage ?: "خطأ غير معروف"}")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        captureButton.isEnabled = false
        showStatus("جاري التقاط الصورة وتحسينها...")
        val photoFile = File(cacheDir, "capture_${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        capture.takePicture(output, cameraExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                try {
                    val original = BitmapFactory.decodeFile(photoFile.absolutePath)
                        ?: throw IllegalStateException("تعذر قراءة الصورة")
                    val enhanced = PhotoEnhancer.enhance(original)
                    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
                    saveToGallery(original, "SmartLens_Original_$stamp.jpg")
                    saveToGallery(enhanced, "SmartLens_Enhanced_$stamp.jpg")
                    original.recycle(); enhanced.recycle(); photoFile.delete()
                    runOnUiThread {
                        captureButton.isEnabled = true
                        showStatus("تم الحفظ: الصورة الأصلية + النسخة المحسّنة")
                        Toast.makeText(this@MainActivity, "تم حفظ الصورتين في المعرض", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        captureButton.isEnabled = true
                        showStatus("حدث خطأ أثناء التحسين: ${e.localizedMessage ?: "حاول مرة أخرى"}")
                    }
                }
            }
            override fun onError(exception: ImageCaptureException) {
                runOnUiThread {
                    captureButton.isEnabled = true
                    showStatus("فشل التصوير: ${exception.localizedMessage ?: "حاول مرة أخرى"}")
                }
            }
        })
    }

    private fun saveToGallery(bitmap: Bitmap, fileName: String): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/SmartLensAI")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        contentResolver.openOutputStream(uri)?.use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out) }
        values.clear(); values.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        return uri
    }

    private fun showStatus(message: String) { if (::statusText.isInitialized) statusText.text = message }

    override fun onDestroy() {
        super.onDestroy()
        if (::cameraExecutor.isInitialized) cameraExecutor.shutdown()
    }
}

/** Global, restrained pixel adjustments only. No face detection, reshaping, skin synthesis or generative edits. */
private object PhotoEnhancer {
    fun enhance(source: Bitmap): Bitmap {
        val width = source.width
        val height = source.height
        val input = IntArray(width * height)
        source.getPixels(input, 0, width, 0, 0, width, height)
        val output = IntArray(input.size)
        // Gentle global contrast and brightness lift; preserve hue and avoid aggressive saturation.
        val contrast = 1.07f
        val brightness = 3.0f
        for (i in input.indices) {
            val c = input[i]
            val r = clamp(((Color.red(c) - 128) * contrast + 128 + brightness).toInt())
            val g = clamp(((Color.green(c) - 128) * contrast + 128 + brightness).toInt())
            val b = clamp(((Color.blue(c) - 128) * contrast + 128 + brightness).toInt())
            output[i] = Color.argb(Color.alpha(c), r, g, b)
        }
        // Very mild unsharp mask-like sharpening, without geometric or facial changes.
        val sharpened = output.copyOf()
        for (y in 1 until height - 1) {
            for (x in 1 until width - 1) {
                val idx = y * width + x
                val center = output[idx]
                val up = output[idx - width]; val down = output[idx + width]
                val left = output[idx - 1]; val right = output[idx + 1]
                fun channel(value: Int, u: Int, d: Int, l: Int, r: Int): Int =
                    clamp((value * 1.12f - (u + d + l + r) * 0.03f).toInt())
                sharpened[idx] = Color.rgb(
                    channel(Color.red(center), Color.red(up), Color.red(down), Color.red(left), Color.red(right)),
                    channel(Color.green(center), Color.green(up), Color.green(down), Color.green(left), Color.green(right)),
                    channel(Color.blue(center), Color.blue(up), Color.blue(down), Color.blue(left), Color.blue(right))
                )
            }
        }
        return Bitmap.createBitmap(sharpened, width, height, Bitmap.Config.ARGB_8888)
    }
    private fun clamp(v: Int) = max(0, min(255, v))
}
